from fastapi import APIRouter

from app.api.endpoints.auth import (
    router as auth_router,
)

from app.api.endpoints.ai_chat import (
    router as ai_chat_router,
)

from app.api.endpoints.users import (
    router as users_router,
)

from app.api.endpoints.parking_facilities import (
    router as parking_facilities_router,
)

from app.api.endpoints.parking_zones import (
    router as parking_zones_router,
)

from app.api.endpoints.parking_bays import (
    router as parking_bays_router,
)

from app.api.endpoints.parking_sessions import (
    router as parking_sessions_router,
)

from app.api.endpoints.parking_tariffs import (
    router as parking_tariffs_router,
)

from app.api.endpoints.parking_reservations import (
    router as parking_reservations_router,
)

from app.api.endpoints.payments import (
    router as payments_router,
)

from app.api.endpoints.receipts import (
    router as receipts_router,
)

from app.api.endpoints.wallets import (
    router as wallets_router,
)

from app.api.endpoints.vehicles import (
    router as vehicles_router,
)

from app.api.endpoints.notifications import (
    router as notifications_router,
)

from app.api.endpoints.loyalty import (
    router as loyalty_router,
)

from app.api.endpoints.loyalty_rewards import (
    router as loyalty_rewards_router,
)

from app.api.endpoints.loyalty_coupons import (
    router as loyalty_coupons_router,
)

from app.api.endpoints.loyalty_referrals import (
    router as loyalty_referrals_router,
)

# ==========================================================
# Production ML Forecasting
# ==========================================================

from app.api.endpoints.forecasts import (
    router as forecasts_router,
)


router = APIRouter()


# ==========================================================
# Authentication
# ==========================================================

router.include_router(
    auth_router,
)


# ==========================================================
# SmartPark AI
# ==========================================================

router.include_router(
    ai_chat_router,
)


# ==========================================================
# Users
# ==========================================================

router.include_router(
    users_router,
)


# ==========================================================
# Parking Facilities
# ==========================================================

router.include_router(
    parking_facilities_router,
)


# ==========================================================
# Parking Zones
# ==========================================================

router.include_router(
    parking_zones_router,
)


# ==========================================================
# Parking Bays
# ==========================================================

router.include_router(
    parking_bays_router,
)


# ==========================================================
# Parking Sessions
# ==========================================================

router.include_router(
    parking_sessions_router,
)


# ==========================================================
# Parking Tariffs
# ==========================================================

router.include_router(
    parking_tariffs_router,
)


# ==========================================================
# Parking Reservations
# ==========================================================

router.include_router(
    parking_reservations_router,
)


# ==========================================================
# Payment Transactions
# ==========================================================

router.include_router(
    payments_router,
)


# ==========================================================
# Receipts
# ==========================================================

router.include_router(
    receipts_router,
)


# ==========================================================
# Wallets
# ==========================================================

router.include_router(
    wallets_router,
)


# ==========================================================
# Vehicles
# ==========================================================

router.include_router(
    vehicles_router,
)


# ==========================================================
# Notifications
# ==========================================================

router.include_router(
    notifications_router,
)


# ==========================================================
# Loyalty Programme
# ==========================================================

router.include_router(
    loyalty_router,
)

router.include_router(
    loyalty_rewards_router,
)

router.include_router(
    loyalty_coupons_router,
)

router.include_router(
    loyalty_referrals_router,
)


# ==========================================================
# Production ML Forecasting
# ==========================================================
#
# Exposes the production occupancy forecasting API.
#
# The forecast endpoint uses:
#
#     PostgreSQL
#          ↓
#     ObservationRepository
#          ↓
#     ProductionForecastService
#          ↓
#     ProductionFeatureBuilder
#          ↓
#     Frozen XGBoost
#
# No training or feature rebuilding occurs at API runtime.
#
# ==========================================================

router.include_router(
    forecasts_router,
)


# ==========================================================
# Root
# ==========================================================

@router.get(
    "/",
    tags=["Root"],
    summary="API Health Check",
)
async def root():
    """
    Root endpoint used to verify the API is running.
    """

    return {
        "application": "SmartPark AI",
        "status": "healthy",
        "version": "1.0.0",
    }
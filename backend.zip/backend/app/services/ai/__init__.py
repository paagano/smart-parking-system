"""
SmartPark AI services.
"""